﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
//Understanding 2d Arrays
//Practice

namespace _2dArra
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = getRow();//assigning x to method getRow()
            int y = getColumn();//assigning y to method getColumn()

            int[,]randomArr = new int[x, y];//loading the rows and column numbers into a 2d array
            LoadArray(x, y,randomArr);//passing the x,y and arrays through parameters into method LoadArray
        }
        //
        public static int getRow()
        {
            string usersRow;
            int row;
            Console.Write("Please enter the number of rows :");
            usersRow = Console.ReadLine();
            row = int.Parse(usersRow);
            return row;
        }
        //Prompts user to enter number of rows, changes string to int
        public static int getColumn()
        {
            string usersColumn;
            int column;
            Console.Write("Please enter the number of columns :");
            usersColumn = Console.ReadLine();
            column = int.Parse(usersColumn);
            return column;
        }

        public static void LoadArray(int x, int y, int[,] randomArr)
        {
            randomArr = new int[x, y];

            Random rnd = new Random();//creates random numbers to put in the arrays

            Console.Write("Your numbers are: ");
            //Reading 2d Array
            for (int h = 0; h < randomArr.GetLength(0); ++h)
            {
                Console.Write("\n");
                for (int n = 0; n < randomArr.GetLength(1); ++n)
                {
                    randomArr[h, n] = rnd.Next(101);//Assigning random numbers to the rows and columns
                    Console.Write(randomArr[0, n] + " ");
                    Console.Write("");
                }
               
            }
            Console.ReadKey();    
        }
    }
}
